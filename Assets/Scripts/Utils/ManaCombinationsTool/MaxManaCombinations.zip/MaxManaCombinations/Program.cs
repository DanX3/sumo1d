﻿// Online C# Editor for free
// Write, Edit and Run your C# code using C# Online Compiler

using System;
using System.Collections.Generic;
using System.Linq;

public class HelloWorld
{
    public static IEnumerable<string> GetCombinations(List<int> set, int sum, string values)
    {
        for (int i = 0; i < set.Count(); i++)
        {
            int left = sum - set[i];
            string vals = "";
            if (left >= 0)
                vals = set[i] + values;

            if (left <= 0)
                yield return vals;

            else
            {
                if (set.Count() > 0)
                {
                    foreach (string s in GetCombinations(set, left, vals))
                    {
                        yield return s;
                    }
                }
            }
        }
    }

    static string SortString(string input)
    {
        char[] characters = input.ToArray();
        Array.Sort(characters);
        return new string(characters);
    }

    public static void Main(string[] args)
    {
        List<int> linesReadFromFile = new();
        List<string> manaCombinationListTEMP = new();
        List<string> manaCombinationListToWrite = new();

        using (StreamReader readtext = new StreamReader("Files\\Input.txt"))
        {
            while (!readtext.EndOfStream)
            {
                linesReadFromFile.Add(int.Parse(readtext.ReadLine()!));
            }
        }

        //se non sono ordinati e distinti da problemi, meglio parsarli per sicurezza
        linesReadFromFile.Sort();
        linesReadFromFile = linesReadFromFile.Distinct().ToList();

        Console.WriteLine("Inserisci numero mana massimo: ");
        int manaMax = Convert.ToInt32(Console.ReadLine());

        foreach (string s in GetCombinations(linesReadFromFile, manaMax, ""))
        {
            if (!String.IsNullOrEmpty(s))
                manaCombinationListTEMP.Add(s);
        }
        //togli tutte le permutazioni esistenti
        manaCombinationListTEMP = manaCombinationListTEMP.Select(x => SortString(x)).Distinct().ToList();
        if (manaCombinationListTEMP.Count() == 0)
        {
            using (StreamWriter writetext = new StreamWriter("Files\\Output.txt"))
            {
                writetext.WriteLine("MAX MANA: " + manaMax + "\n");
                writetext.WriteLine("Nessuna combinazione trovata.");
            }
        }
        foreach (string manaComb in manaCombinationListTEMP)
        {
            char[] splitStr = manaComb.ToCharArray();
            string rejoinedStr = "";
            for (int i = 0; i < splitStr.Count(); i++)
            {
                if (i == splitStr.Count() - 1)
                    rejoinedStr += splitStr[i];
                else
                    rejoinedStr += splitStr[i] + " + ";
            }
            manaCombinationListToWrite.Add(rejoinedStr);
            using (StreamWriter writetext = new StreamWriter("Files\\Output.txt"))
            {
                writetext.WriteLine("MAX MANA: " + manaMax + "\n");

                foreach (string mana in manaCombinationListToWrite)
                {
                    writetext.WriteLine(mana);
                }
            }
        }

        Console.WriteLine("\nFatto!!!");
        Console.Write("\nPress <Enter> to exit... ");
        while (Console.ReadKey().Key != ConsoleKey.Enter) {}
    }
}