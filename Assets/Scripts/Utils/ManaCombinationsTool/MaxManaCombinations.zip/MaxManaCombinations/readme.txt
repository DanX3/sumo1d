Matteo Muratore: allora amici, ho fatto questo piccolo tool che mi ha portato via qualche oretta ma:
1- non ho accesso al mio pc causa fefi fefi coviddata, sto lavorando sul portatile suo ed è un cancro per programmare, quindi non riuscivo proprio ad aprire unity per fare altro;
2- può tornare utile quando dovremo capire quali combinazioni di mana può sfruttare l'AI in base al mana massimo che può utilizzare in quel turno.

Potete Unzippare il tool dove vi pare.

Il tool fa una roba semplice: 
- in un file input.txt (path: bin\Debug\net6.0\Files), riga per riga, bisogna scrivere una lista di numeri corrispondenti al mana di ogni carta presente nel mazzo (non c'è bisogno di fare duplicazioni e non c'è bisogno di essere ordinati, ma se per sbaglio duplicate e disordinate il tool gestisce la cosa correttamente) 
- nella cartella bin\Debug\net6.0 c'è il file .exe da poter aprire in cui viene richiesto di inserire un numero max di mana da voler utilizzare per sapere quali sono le diverse combinazioni: una volta inserito, premete invio e in automatico vi genera un file Output.txt che trovate sempre in bin\Debug\net6.0\Files
- per adesso l'output è solo un TXT, giusto per avere l'info delle combinazioni, ma se pensate possa essere ancor più utile convertirlo in un json che in automatico prende quei dati e facciamo in modo di importarli dentro il componente di unity associato, ditemelo che domani lo faccio.

Se volete sapere cosa fa precisamente il codice, il metodo GetCombinations l'ho preso da StackOverflow e l'ho riadattato per il nostro caso d'uso, ma sinceramente non so bene come funziona di base ahahah so solo che funziona riadattandolo come meglio credevo 
